=======
History
=======

0.2.0 (2020-08-18)
------------------

* First release on PyPI.
