========
seqIOLib
========


.. image:: https://img.shields.io/pypi/v/seqiolib.svg
        :target: https://pypi.python.org/pypi/seqiolib

.. image:: https://img.shields.io/travis/visze/seqiolib.svg
        :target: https://travis-ci.com/visze/seqiolib

.. image:: https://readthedocs.org/projects/seqiolib/badge/?version=latest
        :target: https://seqiolib.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status


.. image:: https://pyup.io/repos/github/visze/seqiolib/shield.svg
     :target: https://pyup.io/repos/github/visze/seqiolib/
     :alt: Updates



Library to read, write sequence, variants, regions to use them for training of machine learning algorithms.


* Free software: MIT license
* Documentation: https://seqiolib.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
