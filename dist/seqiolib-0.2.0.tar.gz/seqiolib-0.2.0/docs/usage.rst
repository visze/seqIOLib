=====
Usage
=====

To use seqIOLib in a project::

    import seqiolib
